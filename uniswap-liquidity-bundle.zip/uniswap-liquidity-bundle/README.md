# Uniswap V2 Liquidity Bundle Executor

## Overview

This project provides a secure and efficient way to add liquidity to Uniswap V2 and execute an initial token purchase in a single transaction. This prevents front-running and ensures you're the first to purchase tokens after adding liquidity.

## Key Features
- Add liquidity and buy tokens in one transaction
- Protection against front-running and sandwich attacks
- Automatic return of unused ETH
- Direct receipt of LP tokens to your wallet
- Works with any ERC20 token
- Full test coverage and security measures

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- An Ethereum wallet with:
  - ETH for gas, liquidity, and buying
  - Tokens for adding liquidity

## Installation

1. Clone the repository:

```bash
git clone https://github.com/seiFunDeploy/uniswap-liquidity-bundle.git
cd uniswap-liquidity-bundle
```

2. Install dependencies:

```bash
npm install
```

3. Create environment file:

```bash
cp .env.local .env
```

4. Configure your `.env` file:

```env
# Network RPC URLs
ETHEREUM_RPC=https://1rpc.io/sepolia
PRIVATE_KEY=your_wallet_private_key

# Contract Parameters
ROUTER_ADDRESS=0xC532a74256D3Db42D0Bf7a0400fEFDbad7694008  # Sepolia UniswapV2Router02 address
FACTORY_ADDRESS=0x7E0987E5b3a30e3f2828572Bb659A548460a3003  # Sepolia UniswapV2Factory address
WETH_ADDRESS=0x7b79995e5f793A07Bc00c21412e50Ecae098E7f9    # Sepolia WETH address

# For testing (adjust as needed)
TEST_TOKEN_AMOUNT=1000  # Amount of tokens for liquidity
ETH_AMOUNT=0.1         # ETH amount for liquidity
BUY_AMOUNT=0.05        # ETH amount for buying
```

## Deployment Guide

### Testing on Sepolia First (Recommended)

1. Get Sepolia ETH from a faucet

2. Deploy your token (if needed):

```bash
npm run deploy:token:sepolia
```

- Save the token address from console output
- Update TOKEN_ADDRESS in your .env file

3. Deploy the executor:

```bash
npm run deploy:executor:sepolia
```

- Save the executor address from console output
- Update EXECUTOR_ADDRESS in your .env file

4. Test the deployment:

```bash
npm run test:deployment:sepolia
```

5. Verify the pool:

```bash
npm run verify:pool:sepolia
```

### Mainnet Deployment

After successful testing on Sepolia:

1. Update .env with mainnet values:

```env
ETHEREUM_RPC=https://eth.llamarpc.com/
PRIVATE_KEY=your_wallet_private_key

# Ethereum Mainnet Addresses
ROUTER_ADDRESS=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D  # UniswapV2Router02
FACTORY_ADDRESS=0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f  # UniswapV2Factory
WETH_ADDRESS=0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2    # WETH9

# Update other values for mainnet
```

2. Deploy to mainnet:

```bash
npm run deploy:token:mainnet      # If deploying a new token
npm run deploy:executor:mainnet
```

3. Test mainnet deployment:

```bash
npm run test:deployment:mainnet
```

4. Verify mainnet pool:

```bash
npm run verify:pool:mainnet
```

## Usage Guide

### Adding Liquidity and Buying Tokens

1. Approve tokens:
   - Your tokens must be approved for the executor contract
   - This happens automatically in the test script

2. Calculate amounts:
   - Token amount for liquidity
   - ETH amount for liquidity
   - ETH amount for buying
   - Total ETH needed = Liquidity ETH + Buy ETH

3. Execute the bundle:
   - The contract handles everything in one transaction
   - LP tokens come directly to your wallet
   - Bought tokens come directly to your wallet
   - Unused ETH is returned automatically

### Security Features

- All operations happen in one transaction
- No opportunity for front-running
- LP tokens sent directly to you
- Bought tokens sent directly to you
- Allowances cleared after use
- Direct ETH transfers blocked

### Monitoring Your Position

Check your pool position:

```bash
npm run verify:pool:mainnet  # or :sepolia for testnet
```

This shows:

- Pool reserves
- Your LP token balance
- Pool ownership percentage
- Current prices

## Common Parameters

- `tokenAmount`: Amount of tokens to add to liquidity
- `ethAmount`: Amount of ETH to add to liquidity
- `buyAmount`: Amount of ETH to use for buying tokens
- `minTokens`: Minimum tokens to receive from buy (use 0 for no minimum)

## Troubleshooting

1. "Insufficient ETH sent"
   - Ensure you're sending enough ETH for both liquidity and buying
   - Add extra for gas fees

2. "Liquidity addition failed"
   - Verify token approvals
   - Check token balance
   - Confirm ETH amount

3. Transaction Reverts
   - Check gas limit (recommend 3000000)
   - Verify all balances and allowances
   - Ensure price impact isn't too high

## Support and Contact

For support:

- Open an issue in the repository
- Contact: [email]
- Documentation: [here](./README.md)

## Security Considerations

- Keep your private key secure
- Test thoroughly on Sepolia first
- Verify all addresses and amounts
- Monitor transactions carefully
- Use reasonable slippage protection
