const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-network-helpers");

describe("LiquidityBundleExecutor", function () {
    async function deployFixture() {
        const [owner, user1, user2] = await ethers.getSigners();

        // Deploy mock WETH
        const MockWETH = await ethers.getContractFactory("MockWETH");
        const weth = await (await MockWETH.deploy()).waitForDeployment();

        // Deploy mock token
        const MockToken = await ethers.getContractFactory("MockToken");
        const token = await (await MockToken.deploy("Test Token", "TEST")).waitForDeployment();

        // Deploy mock factory
        const MockFactory = await ethers.getContractFactory("MockUniswapV2Factory");
        const factory = await (await MockFactory.deploy(owner.address)).waitForDeployment();

        // Deploy mock router
        const MockRouter = await ethers.getContractFactory("MockUniswapV2Router02");
        const router = await (await MockRouter.deploy(
            await factory.getAddress(),
            await weth.getAddress()
        )).waitForDeployment();

        // Deploy executor
        const LiquidityBundleExecutor = await ethers.getContractFactory("LiquidityBundleExecutor");
        const executor = await (await LiquidityBundleExecutor.deploy(
            await router.getAddress()
        )).waitForDeployment();

        // Mint initial tokens
        const initialTokenAmount = ethers.parseEther("1000000");
        await token.mint(user1.address, initialTokenAmount);

        // Get contract addresses
        const executorAddress = await executor.getAddress();
        const tokenAddress = await token.getAddress();
        const wethAddress = await weth.getAddress();
        const factoryAddress = await factory.getAddress();
        const routerAddress = await router.getAddress();

        return {
            executor,
            token,
            weth,
            factory,
            router,
            owner,
            user1,
            user2,
            addresses: {
                executor: executorAddress,
                token: tokenAddress,
                weth: wethAddress,
                factory: factoryAddress,
                router: routerAddress
            }
        };
    }

    describe("Constructor & Initial State", function () {
        it("Should set correct router address", async function () {
            const { executor, addresses } = await loadFixture(deployFixture);
            expect(await executor.uniswapRouter()).to.equal(addresses.router);
        });

        it("Should set correct factory address", async function () {
            const { executor, addresses } = await loadFixture(deployFixture);
            expect(await executor.uniswapFactory()).to.equal(addresses.factory);
        });

        it("Should set correct WETH address", async function () {
            const { executor, addresses } = await loadFixture(deployFixture);
            expect(await executor.WETH()).to.equal(addresses.weth);
        });
    });

    describe("executeBundle", function () {
        describe("Happy Path", function () {
            it("Should successfully add liquidity and execute bundle buy", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);
        
                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");
        
                // Approve tokens
                await token.connect(user1).approve(addresses.executor, tokenAmount);
        
                // Get balance before
                const balanceBefore = await token.balanceOf(user1.address);
        
                // Execute bundle
                const tx = await executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount }
                );
        
                // Wait for transaction
                await tx.wait();
        
                // Get balance after
                const balanceAfter = await token.balanceOf(user1.address);
        
                // Should get back some tokens from the swap
                expect(balanceAfter - balanceBefore).to.be.gt(0);
            });

            it("Should return unused ETH to sender", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);

                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");
                const extraEth = ethers.parseEther("1");

                await token.connect(user1).approve(addresses.executor, tokenAmount);

                const initialBalance = await ethers.provider.getBalance(user1.address);

                const tx = await executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount + extraEth }
                );

                const receipt = await tx.wait();
                const gasSpent = receipt.gasUsed * receipt.gasPrice;

                const finalBalance = await ethers.provider.getBalance(user1.address);
                expect(finalBalance).to.be.closeTo(
                    initialBalance - ethAmount - buyAmount - gasSpent,
                    ethers.parseEther("0.0001")
                );
            });
        });

        describe("Edge Cases & Error Conditions", function () {
            it("Should revert if insufficient ETH sent", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);

                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");

                await token.connect(user1).approve(addresses.executor, tokenAmount);

                await expect(executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount } // Not sending enough ETH for buy
                )).to.be.revertedWith("Insufficient ETH sent");
            });

            it("Should revert if token approval not given", async function () {
                const { executor, user1, addresses } = await loadFixture(deployFixture);

                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");

                await expect(executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount }
                )).to.be.reverted; // ERC20 reverts on insufficient allowance
            });

            it("Should revert if insufficient token balance", async function () {
                const { executor, token, user2, addresses } = await loadFixture(deployFixture);

                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");

                await token.connect(user2).approve(addresses.executor, tokenAmount);

                await expect(executor.connect(user2).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount }
                )).to.be.reverted; // ERC20 reverts on insufficient balance
            });

            it("Should revert if minTokens requirement not met", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);
            
                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");
                const highMinTokens = ethers.parseEther("1000000"); // Unreasonable amount
            
                await token.connect(user1).approve(addresses.executor, tokenAmount);
            
                await expect(executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    highMinTokens,
                    { value: ethAmount + buyAmount }
                )).to.be.revertedWith("INSUFFICIENT_OUTPUT_AMOUNT");
            });
        });

        describe("Security Considerations", function () {
            it("Should clear token approvals after execution", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);
                
                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");
                
                await token.connect(user1).approve(addresses.executor, tokenAmount);
                
                await executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount }
                );
        
                expect(await token.allowance(addresses.executor, await executor.uniswapRouter()))
                    .to.equal(0);
            });
        
            it("Should not allow direct ETH transfers", async function () {
                const { addresses, user1 } = await loadFixture(deployFixture);
                
                await expect(user1.sendTransaction({
                    to: addresses.executor,
                    value: ethers.parseEther("1")
                })).to.be.revertedWith("Direct ETH transfers not allowed");
            });
        });

        describe("Gas Optimization", function () {
            it("Should complete operation within reasonable gas limits", async function () {
                const { executor, token, user1, addresses } = await loadFixture(deployFixture);

                const tokenAmount = ethers.parseEther("1000");
                const ethAmount = ethers.parseEther("10");
                const buyAmount = ethers.parseEther("2");

                await token.connect(user1).approve(addresses.executor, tokenAmount);

                const tx = await executor.connect(user1).executeBundle(
                    addresses.token,
                    tokenAmount,
                    ethAmount,
                    buyAmount,
                    0,
                    { value: ethAmount + buyAmount }
                );

                const receipt = await tx.wait();
                expect(receipt.gasUsed).to.be.below(500000);
            });
        });
    });
});