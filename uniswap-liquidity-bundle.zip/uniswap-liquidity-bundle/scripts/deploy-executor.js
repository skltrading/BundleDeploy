const hre = require("hardhat");

async function main() {
  const ROUTER_ADDRESS = process.env.ROUTER_ADDRESS;
  
  console.log("Deploying LiquidityBundleExecutor...");
  
  const LiquidityBundleExecutor = await hre.ethers.getContractFactory("LiquidityBundleExecutor");
  const executor = await LiquidityBundleExecutor.deploy(ROUTER_ADDRESS);
  await executor.waitForDeployment();
  
  const executorAddress = await executor.getAddress();
  console.log(`LiquidityBundleExecutor deployed to: ${executorAddress}`);
  
  // Wait for some block confirmations
  await executor.deploymentTransaction().wait(5);
  
  // Verify contract on Etherscan
  console.log("Verifying contract on Etherscan...");
  try {
    await hre.run("verify:verify", {
      address: executorAddress,
      constructorArguments: [ROUTER_ADDRESS],
    });
  } catch (e) {
    console.log("Verification error:", e);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });