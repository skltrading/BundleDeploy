const hre = require("hardhat");

async function main() {
  console.log("Deploying TestToken...");
  
  const TestToken = await hre.ethers.getContractFactory("TestToken");
  const token = await TestToken.deploy();
  await token.waitForDeployment();
  
  const tokenAddress = await token.getAddress();
  console.log(`TestToken deployed to: ${tokenAddress}`);
  
  // Wait for some block confirmations
  await token.deploymentTransaction().wait(5);
  
  // Verify contract on Etherscan
  console.log("Verifying contract on Etherscan...");
  try {
    await hre.run("verify:verify", {
      address: tokenAddress,
      constructorArguments: [],
    });
  } catch (e) {
    console.log("Verification error:", e);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });