const hre = require("hardhat");
require('dotenv').config();

async function main() {
    console.log("Starting deployment test...");

    // Validate environment variables
    if (!process.env.TOKEN_ADDRESS) throw new Error("TOKEN_ADDRESS not set in .env");
    if (!process.env.EXECUTOR_ADDRESS) throw new Error("EXECUTOR_ADDRESS not set in .env");
    if (!process.env.TEST_TOKEN_AMOUNT) throw new Error("TEST_TOKEN_AMOUNT not set in .env");
    if (!process.env.ETH_AMOUNT) throw new Error("ETH_AMOUNT not set in .env");
    if (!process.env.BUY_AMOUNT) throw new Error("BUY_AMOUNT not set in .env");

    console.log(`Token Address: ${process.env.TOKEN_ADDRESS}`);
    console.log(`Executor Address: ${process.env.EXECUTOR_ADDRESS}`);

    // Get contract instances
    const token = await hre.ethers.getContractAt(
        "TestToken",
        process.env.TOKEN_ADDRESS
    );

    const executor = await hre.ethers.getContractAt(
        "LiquidityBundleExecutor",
        process.env.EXECUTOR_ADDRESS
    );

    // Get router information
    const routerAddress = await executor.uniswapRouter();
    const factoryAddress = await executor.uniswapFactory();
    const wethAddress = await executor.WETH();
    
    console.log("\nContract Setup:");
    console.log(`Router Address: ${routerAddress}`);
    console.log(`Factory Address: ${factoryAddress}`);
    console.log(`WETH Address: ${wethAddress}`);

    // Get signer
    const [signer] = await hre.ethers.getSigners();
    console.log(`\nUsing account: ${signer.address}`);

    // Check initial balances
    const tokenBalance = await token.balanceOf(signer.address);
    const ethBalance = await hre.ethers.provider.getBalance(signer.address);
    
    console.log("\nInitial Balances:");
    console.log(`Token Balance: ${hre.ethers.formatEther(tokenBalance)} TEST`);
    console.log(`ETH Balance: ${hre.ethers.formatEther(ethBalance)} ETH`);

    // Parse amounts
    const tokenAmount = hre.ethers.parseEther(process.env.TEST_TOKEN_AMOUNT);
    const ethAmount = hre.ethers.parseEther(process.env.ETH_AMOUNT);
    const buyAmount = hre.ethers.parseEther(process.env.BUY_AMOUNT);
    const totalEthNeeded = ethAmount + buyAmount;

    console.log("\nTransaction Parameters:");
    console.log(`Token Amount: ${hre.ethers.formatEther(tokenAmount)} TEST`);
    console.log(`ETH Amount: ${hre.ethers.formatEther(ethAmount)} ETH`);
    console.log(`Buy Amount: ${hre.ethers.formatEther(buyAmount)} ETH`);
    console.log(`Total ETH Needed: ${hre.ethers.formatEther(totalEthNeeded)} ETH`);

    // Check if we have enough balance
    if (tokenBalance < tokenAmount) {
        throw new Error(`Insufficient token balance. Have ${hre.ethers.formatEther(tokenBalance)}, need ${hre.ethers.formatEther(tokenAmount)}`);
    }
    if (ethBalance < totalEthNeeded) {
        throw new Error(`Insufficient ETH balance. Have ${hre.ethers.formatEther(ethBalance)}, need ${hre.ethers.formatEther(totalEthNeeded)}`);
    }

    // Check current allowance
    const currentAllowance = await token.allowance(signer.address, await executor.getAddress());
    console.log(`\nCurrent Allowance: ${hre.ethers.formatEther(currentAllowance)} TEST`);

    // Approve tokens if needed
    if (currentAllowance < tokenAmount) {
        console.log("\nApproving tokens...");
        const approveTx = await token.approve(await executor.getAddress(), tokenAmount);
        console.log(`Approval tx hash: ${approveTx.hash}`);
        await approveTx.wait();
        console.log("Tokens approved");
    } else {
        console.log("\nSufficient allowance exists, skipping approval");
    }

    // Try to estimate gas first
    console.log("\nEstimating gas...");
    try {
        const gasEstimate = await executor.executeBundle.estimateGas(
            await token.getAddress(),
            tokenAmount,
            ethAmount,
            buyAmount,
            0, // minTokens
            {
                value: totalEthNeeded
            }
        );
        console.log(`Estimated gas: ${gasEstimate.toString()}`);
    } catch (error) {
        console.error("Gas estimation failed:");
        console.error(error);
        if (error.reason) console.error("Reason:", error.reason);
        throw error;
    }

    // Execute bundle
    console.log("\nExecuting bundle...");
    try {
        const tx = await executor.executeBundle(
            await token.getAddress(),
            tokenAmount,
            ethAmount,
            buyAmount,
            0, // minTokens
            {
                value: totalEthNeeded,
                gasLimit: 3000000
            }
        );
        
        console.log(`Transaction hash: ${tx.hash}`);
        const receipt = await tx.wait();
        console.log(`Transaction status: ${receipt.status === 1 ? 'Success' : 'Failed'}`);
        
        // Get final balances
        const finalTokenBalance = await token.balanceOf(signer.address);
        const finalEthBalance = await hre.ethers.provider.getBalance(signer.address);
        
        console.log("\nFinal Balances:");
        console.log(`Token Balance: ${hre.ethers.formatEther(finalTokenBalance)} TEST`);
        console.log(`ETH Balance: ${hre.ethers.formatEther(finalEthBalance)} ETH`);
        
    } catch (error) {
        console.error("\nTransaction failed:");
        console.error("Error message:", error.message);
        if (error.reason) console.error("Reason:", error.reason);
        if (error.data) console.error("Error data:", error.data);
        if (error.transaction) console.error("Transaction:", error.transaction);
        if (error.receipt) console.error("Receipt:", error.receipt);
        throw error;
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("\nScript failed:");
        console.error(error);
        process.exit(1);
    });