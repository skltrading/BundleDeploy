const hre = require("hardhat");
require('dotenv').config();

async function main() {
    console.log("Starting pool verification...");

    // Get addresses from env
    const tokenAddress = process.env.TOKEN_ADDRESS;
    const executorAddress = process.env.EXECUTOR_ADDRESS;

    // Get contract instances
    const token = await hre.ethers.getContractAt("TestToken", tokenAddress);
    const executor = await hre.ethers.getContractAt("LiquidityBundleExecutor", executorAddress);
    
    // Get Uniswap contracts
    const routerAddress = await executor.uniswapRouter();
    const factoryAddress = await executor.uniswapFactory();
    const wethAddress = await executor.WETH();

    console.log("\nContract Addresses:");
    console.log(`Token: ${tokenAddress}`);
    console.log(`WETH: ${wethAddress}`);
    console.log(`Router: ${routerAddress}`);
    console.log(`Factory: ${factoryAddress}`);

    // Get pool information
    const factory = await hre.ethers.getContractAt("IUniswapV2Factory", factoryAddress);
    const pairAddress = await factory.getPair(wethAddress, tokenAddress);

    console.log(`\nPool Address: ${pairAddress}`);

    if (pairAddress === "0x0000000000000000000000000000000000000000") {
        console.log("No pool exists for this token yet!");
        return;
    }

    // Get pool details
    const pair = await hre.ethers.getContractAt("IUniswapV2Pair", pairAddress);
    const [token0, token1] = await Promise.all([
        pair.token0(),
        pair.token1()
    ]);

    console.log("\nPool Configuration:");
    console.log(`Token0: ${token0} ${token0.toLowerCase() === wethAddress.toLowerCase() ? '(WETH)' : '(TOKEN)'}`);
    console.log(`Token1: ${token1} ${token1.toLowerCase() === wethAddress.toLowerCase() ? '(WETH)' : '(TOKEN)'}`);

    try {
        // Get reserves
        const reserves = await pair.getReserves();
        const reserve0 = reserves[0];
        const reserve1 = reserves[1];

        // Determine which reserve is which token
        const isToken0WETH = token0.toLowerCase() === wethAddress.toLowerCase();
        const wethReserve = isToken0WETH ? reserve0 : reserve1;
        const tokenReserve = isToken0WETH ? reserve1 : reserve0;

        console.log("\nPool Reserves:");
        console.log(`Token Reserve: ${hre.ethers.formatEther(tokenReserve)} TEST`);
        console.log(`WETH Reserve: ${hre.ethers.formatEther(wethReserve)} WETH`);

        // Get LP token information
        const [signer] = await hre.ethers.getSigners();
        const lpBalance = await pair.balanceOf(signer.address);
        const totalSupply = await pair.totalSupply();

        console.log("\nLP Token Information:");
        console.log(`Your LP Balance: ${hre.ethers.formatEther(lpBalance)} LP`);
        console.log(`Total LP Supply: ${hre.ethers.formatEther(totalSupply)} LP`);

        if (totalSupply > 0n && lpBalance > 0n) {
            // Calculate ownership percentage
            const ownershipPercentage = Number((lpBalance * 10000n) / totalSupply) / 100;
            console.log(`Your Pool Ownership: ${ownershipPercentage}%`);
        }

        if (tokenReserve > 0n && wethReserve > 0n) {
            // Calculate prices
            const tokenPriceInEth = (wethReserve * BigInt(1e18)) / tokenReserve;
            const ethPriceInToken = (tokenReserve * BigInt(1e18)) / wethReserve;
            
            console.log("\nPrices:");
            console.log(`1 TOKEN = ${hre.ethers.formatEther(tokenPriceInEth)} WETH`);
            console.log(`1 WETH = ${hre.ethers.formatEther(ethPriceInToken)} TOKEN`);
        }

    } catch (error) {
        console.error("\nError fetching pool details:", error);
        throw error;
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("\nError in pool verification:");
        console.error(error);
        process.exit(1);
    });